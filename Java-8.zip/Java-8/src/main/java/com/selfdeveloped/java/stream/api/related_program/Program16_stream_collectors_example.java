package com.selfdeveloped.java.stream.api.related_program;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Program16_stream_collectors_example 
{
	public static void main(String[] args) {
        List<Persons> list = Persons.getList();
        Map<Integer, String> nameByAge
                = list.stream().collect(Collectors.groupingBy(Persons::getAge,
	                						Collectors.mapping(
	                								Persons::getName, Collectors.joining(",")
	                						)));
        nameByAge.forEach((k,v)->System.out.println("Age:"+k +"  Persons: "+v));
        
        List<String> list9 = Stream.of("AA","BB","CC").collect(Collectors.toList());
        list9.forEach(s->System.out.println(s));

        Set<String> set = Stream.of("AA","AA","BB").collect(Collectors.toSet());
        set.forEach(s->System.out.println(s));

        Map<String,String> map = Stream.of("AA","BB","CC").collect(Collectors.toMap(k->k, v->v+v));
        map.forEach((k,v)->System.out.println("key:"+k +"  value:"+v));
        
        List<Integer> list4 = Arrays.asList(1,2,3,4);
        long result4=  list4.stream().collect(Collectors.counting());
        System.out.println(result4);
	}

}
