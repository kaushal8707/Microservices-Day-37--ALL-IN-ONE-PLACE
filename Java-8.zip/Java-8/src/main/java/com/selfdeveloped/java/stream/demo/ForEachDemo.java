package com.selfdeveloped.java.stream.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ForEachDemo {

	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("perk");
		list.add("absco");
		list.add("defto");
		list.add("vesko");
		list.add("softy");
		list.stream().forEach(t-> System.out.println(t));
		list.stream().forEach(System.out::print);
		
		Map<Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "one");
		map.put(2, "two");
		map.put(3, "three");
		map.put(4, "four");
		map.put(5, "five");
		
		map.forEach((key, value)-> System.out.println(key+"  : "+value));
		map.entrySet().stream().forEach(obj-> System.out.println(obj));
		map.entrySet().forEach(System.out::print); 
		map.entrySet().stream().forEach(System.out::print); 


	}

}
