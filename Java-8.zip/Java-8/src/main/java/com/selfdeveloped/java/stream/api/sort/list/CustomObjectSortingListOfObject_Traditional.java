package com.selfdeveloped.java.stream.api.sort.list;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CustomObjectSortingListOfObject_Traditional {

	public static void main(String[] args) {
		List<Employee> list = EmployeeDB.getEmployees();
		Collections.sort(list, new MyComparator());
		for(Employee emp : list) {
			System.out.println("Employee : "+emp);
		}
	}
}

class MyComparator implements Comparator<Employee>
{
	public int compare(Employee e1, Employee e2) {
		return e1.getName().compareTo(e2.getName());
	}
}
