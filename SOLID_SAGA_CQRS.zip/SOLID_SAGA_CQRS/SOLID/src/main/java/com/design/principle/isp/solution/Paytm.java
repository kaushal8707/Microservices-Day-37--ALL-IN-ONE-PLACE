package com.design.principle.isp.solution;

public class Paytm implements UPIPayments {

    public void payMoney() {

    }

    public void getScratchCard() {

    }


}
