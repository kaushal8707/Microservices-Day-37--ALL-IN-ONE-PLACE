package com.selfdeveloped.java.stream.api.related_program;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Program14_stream_findAny_findFirst_example {

	public static void main(String[] args) {
		 Stream.of(11,55,33,77,22,88).findAny().ifPresent(s->System.out.println(s));

	        List<String> list = Arrays.asList("Mahesh", "Suresh", "Mohit");
	        String output = list.stream()
	                .filter(e -> e.startsWith("M"))
	                .findAny()
	                .orElse("NA");
	        System.out.println(output);

	        List<Integer> numList = Arrays.asList(21, 22, 23, 24);
	        numList.stream()
	                .filter(n -> n % 2 == 0)
	                .findAny()
	                .ifPresent(e -> System.out.println(e));


	        List<User> list1 = new ArrayList<>();
	        list1.add(new User("Emp A", 20));
	        list1.add(new User("Emp B", 30));
	        list1.add(new User("Emp C", 35));
	        list1.add(new User("Emp D", 40));

	        list1.stream()
	                .filter(e -> e.getAge() >= 30 && e.getAge() <= 40)
	                .map(e -> e.getUserName())
	                .findAny()
	                .ifPresent(s -> System.out.println(s));

//	        Stream.of(null, "AA").
//	                findAny().ifPresent(s -> System.out.println(s));
	        
	        List<Integer> list2= Arrays.asList(2,7,4,1,9,11);
	        Optional<Integer> optional=list2.stream().findFirst();
	        optional.ifPresent(e->System.out.println(e));

	        list2.stream().filter(num->num%2!=0).findFirst().ifPresent(s->System.out.println(s));


	        //findFirst example with null value.
//	        Stream.of(null, "A").
//	                findFirst().ifPresent(s -> System.out.println(s));
	}

}
