package com.selfdeveloped.java.functional.interfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class SupplierDemo implements Supplier<String> {

	@Override
	public String get() {
		return "Hello Java Programmer";
	}
	
	public static void main(String[] args) {
		
		//Traditional Way
		Supplier<String> supply = new SupplierDemo();
		System.out.println(supply.get());
		
		//Using Lambda Expression
		Supplier<String> supplier = ()->  "Hi Java Programmer";
		System.out.println(supplier.get());
		
		//In Real time Scenario In java 8 if we are doing filtering process and we are not getting any result,
		//but you want some dummy data or some meaningful response in such case you can go for Supplier
	
	   List<String> list = Arrays.asList("a", "b");
	   System.out.println(list.stream().findAny().orElseGet(supplier));
	   
	   List<String> list1 = Arrays.asList();
	   Supplier<String> supp = ()->  "Please add data into a list";
	   System.out.println(list1.stream().findAny().orElseGet(supp));
	
	
	}

}
