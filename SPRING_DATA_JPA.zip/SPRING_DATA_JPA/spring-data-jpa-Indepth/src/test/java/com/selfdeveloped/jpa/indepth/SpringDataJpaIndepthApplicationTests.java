package com.selfdeveloped.jpa.indepth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaIndepthApplicationTests {

	@Test
	void contextLoads() {
	}

}
