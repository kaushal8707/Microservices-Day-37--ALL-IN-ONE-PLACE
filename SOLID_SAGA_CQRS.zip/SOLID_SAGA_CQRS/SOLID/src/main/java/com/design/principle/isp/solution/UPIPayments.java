package com.design.principle.isp.solution;

public interface UPIPayments {

    public void payMoney();

    public void getScratchCard();


}
