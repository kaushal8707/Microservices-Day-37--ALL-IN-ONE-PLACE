package com.selfdeveloped.java.stream.api.sort.map;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class SortMapDemoUsingStreamAPI {

	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("two", 2);
		map.put("four", 4);
		map.put("six", 6);
		map.put("eight", 8);
		map.put("nine", 9);
		
		//Based on Key Sorting
		map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
		
		//Based on Value Sorting
		map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
	}
}
