package com.selfdeveloped.java.stream.api.related_program;
import java.util.List;
import java.util.stream.Collectors;

public class ImpQuestion {

	public static void main(String[] args) {
	    List<Users> list = Users.getUsers();
	    
        // Stream filter() with mapToInt() and sum()
	    // find the 
        List<Users> list1 = Users.getUsers();
        System.out.println("--- Sum of age between the user id 2 and 4 ---");
        int sum = list1.stream().filter(u -> u.getId() >= 2 && u.getId() <= 4)
                .mapToInt(u -> u.getAge()).sum();
        System.out.println("Sum: " + sum);

        double avg=list1.stream().filter(t->t.getId()>=2 && t.getId()<=4).mapToInt(t->t.getAge()).average().getAsDouble();
        System.out.println("Average = "+avg);
        
        double max=list1.stream().filter(t->t.getId()>=2 && t.getId()<=4).mapToInt(t->t.getAge()).max().getAsInt();
        		System.out.println("Max = "+max);
        
        double min=list1.stream().filter(t->t.getId()>=2 && t.getId()<=4).mapToInt(t->t.getAge()).min().getAsInt();
        System.out.println("Min = "+min);

        //Stream filter() with collect()
        List<Users> list2 = Users.getUsers();
        long count = list2.stream().filter(u -> u.getName().endsWith("sh"))
                .collect(Collectors.counting());
        System.out.println("Number of users ending name with 'sh': "+ count);
        
        
	}

}
