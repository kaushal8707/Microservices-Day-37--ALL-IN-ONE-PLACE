package com.java.core.selfdeveloped.THREADING;

public class DataReciever {
    static public void show(String data) {
        System.out.println(data);
    }
}
