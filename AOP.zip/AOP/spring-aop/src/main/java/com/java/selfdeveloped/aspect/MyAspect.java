package com.java.selfdeveloped.aspect;
import java.util.Arrays;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyAspect {
	@Before("execution(* com.java.selfdeveloped.service.HiByeService.*(..))")  
	public void before(JoinPoint joinPoint) {
		System.out.print("Before ->");
		System.out.print(joinPoint.getSignature().getName() + " called with ");
		System.out.println(Arrays.toString(joinPoint.getArgs()));
		System.out.println(Arrays.toString(joinPoint.getArgs()));

	}
	
	@After("execution(* com.java.selfdeveloped.service.HiByeService.*(..))")  
	public void after(JoinPoint joinPoint) {
		System.out.print("After -> ");
		System.out.println(joinPoint.getSignature().getName());
	}
	@AfterReturning(pointcut = "execution(* com.java.selfdeveloped.service.HiByeService.*(..))", returning = "result")
	public void after(JoinPoint joinPoint, Object result) {
		System.out.print("After Returning -> ");
		System.out.print(joinPoint.getSignature().getName());
		System.out.println(" result is " + result);
	}
}
