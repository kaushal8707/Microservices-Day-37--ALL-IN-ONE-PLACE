package com.selfdeveloped.java.stream.api.sort.list;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortListDemo {
	public static void main(String[] args) {

		//Traditional Approach ( For Custom Object we need to use Either Comparable or Comparator )
		//Collections.sort can be use for Primitive data type or Wrapper class object 
		
		List<Integer> list = Arrays.asList(6,1,8,6,9,1,4);
		Collections.sort(list);     //Ascending
		list.forEach(System.out::print);
		System.out.println();
		Collections.reverse(list);   //Descending
		list.forEach(System.out::print);
		
		//Using Lambda Expression
		list.stream().sorted().forEach(System.out::println);
		list.stream().sorted(Comparator.reverseOrder()).forEach(System.out::print);
		list.stream().distinct().collect(Collectors.toList()).forEach(System.out::println);
	}
}
