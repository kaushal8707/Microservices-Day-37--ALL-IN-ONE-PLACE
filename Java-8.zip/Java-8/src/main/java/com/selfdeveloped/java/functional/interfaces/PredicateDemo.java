package com.selfdeveloped.java.functional.interfaces;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateDemo implements Predicate<Integer> {
	
	@Override
	public boolean test(Integer t) {
		if(t%2==0) {
			return true;
		}else {
			return false;
		}
	}
	public static void main(String[] args) {
		
	//Using Traditional Way
	Predicate<Integer> p = new PredicateDemo();
	System.out.println(p.test(13));
	
	//Using Lambda Expression 
		Predicate<Integer> res = (t)->t%2==0;
		System.out.println(res.test(12));
		
		
	List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
	list.stream().filter(t->t%2==0).forEach(System.out::print);
						//OR
//	Predicate<Integer> pred = t->t%2==0;
//	list.stream().filter(pred).forEach(System.out::print);

	}
}
