package com.selfdeveloped.java.map.vs.flatmap;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
@AllArgsConstructor
@ToString
@Getter
public class Customer {

	private int id;
	private long salary;
	private String name;
	private String email;
	private List<String> phoneNumbers;
}
