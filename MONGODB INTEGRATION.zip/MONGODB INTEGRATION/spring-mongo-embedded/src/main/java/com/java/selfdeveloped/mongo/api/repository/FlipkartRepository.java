package com.java.selfdeveloped.mongo.api.repository;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import com.java.selfdeveloped.mongo.api.model.User;

public interface FlipkartRepository extends MongoRepository<User, Integer>{

	List<User> findByName(String name);

	@Query("{'Address.city':?0}")
	List<User> findByCity(String city);

	@Query("{gender: ?0}")
	List<User> findByGender(String gender);
	
	@Query("{gender: ?0, name: ?1}")
	List<User> findByGenderAndName(String gender, String name);
	
}

