package com.selfdeveloped.java.stream.api.related_program;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User
{
    private String userName;
    private int age;

   
    public void showData()
    {
        System.out.println(userName+"  "+age);
    }
    public static void viewRecord()
    {
        System.out.println("inside static ref");
    }
}
