package com.selfdeveloped.ProductService.query.api.queries;

public class GetProductQuery {

}
