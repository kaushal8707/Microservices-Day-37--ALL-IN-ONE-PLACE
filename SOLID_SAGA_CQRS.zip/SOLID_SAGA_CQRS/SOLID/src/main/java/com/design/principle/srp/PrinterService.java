package com.design.principle.srp;

public class PrinterService {

    public void printPassbook() {
        //update transaction info in passbook
    }
}
