package com.selfdeveloped.jpa.repository;
import java.util.List;
import javax.persistence.LockModeType;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.selfdeveloped.jpa.dto.OrderResponse;
import com.selfdeveloped.jpa.entity.Customer;

	public interface CustomerRepository extends JpaRepository<Customer,Integer> {
		@Query("SELECT new com.selfdeveloped.jpa.dto.OrderResponse(c.name, p.productName) FROM Customer c JOIN c.products p")
		public List<OrderResponse> getJoinInformation();
		
		 @Transactional
		 @Modifying
		 @Query("update Customer set email=:email where id=:id")
		 public void updateEmail(@Param("id") int id, @Param("email") String email);

		 //Indexed Query
		 @Query("select c from Customer c where c.name=:name") 
		 List<Customer> getAllCustomerByNames(@Param("name") String name);

		 //Native Query
		 @Query(value = "select c from customer c where c.email=:email",nativeQuery=true)
		 List<Customer> getAllCustomerByEmail(@Param("email") String email);

		 //JPQL
		 @Query("select c from Customer c where c.email=:email")
		 List<Customer> getCustomerByEmail(@Param("email") String email);

		 @Transactional
		 @Modifying
		 @Query("update Customer set email=?2 where id=?1")
		 @Lock(LockModeType.NONE)
		 public void changeEmail(int id, String email);
	}

