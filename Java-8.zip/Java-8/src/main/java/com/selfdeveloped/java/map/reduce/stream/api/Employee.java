package com.selfdeveloped.java.map.reduce.stream.api;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Employee{
	private int id;
	private String name;
	private String grade;
	private double salary;
}
