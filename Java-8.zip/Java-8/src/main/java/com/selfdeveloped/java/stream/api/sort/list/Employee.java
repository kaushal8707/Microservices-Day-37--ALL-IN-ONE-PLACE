package com.selfdeveloped.java.stream.api.sort.list;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@Getter
public class Employee 
{
	private int id;
	private String name;
	private String dept;
	private long salary;
}
