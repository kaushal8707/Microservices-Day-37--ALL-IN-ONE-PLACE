package com.java.selfdeveloped.creational.design.pattern.singleton;


//Instead of Synchronized Method we need to use Synchronized Block

public class Singleton_Using_Double_Checked_Locking {

	public static void main(String[] args) {
		
		Thread t1=new Thread(new Runnable() {	
		public void run() {
			Abs obj1=Abs.getInstance();
			}
		});
		Thread t2=new Thread(new Runnable() {	
			public void run() {
				Abs obj2=Abs.getInstance();
				}
		});
		t1.start();
		t2.start();
	}

}

class Abs{
	static Abs obj;
	private Abs() {
		System.out.println("Instance Created");
	}
	
	public static Abs getInstance(){
		if(obj==null) {
			synchronized(Abs.class) {
			 if(obj==null) {
			    obj = new Abs();
		  	 }
		  }
		}
			return obj;
	}
}
