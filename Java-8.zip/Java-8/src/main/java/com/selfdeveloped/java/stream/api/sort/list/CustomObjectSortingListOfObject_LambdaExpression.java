package com.selfdeveloped.java.stream.api.sort.list;

import java.util.Collections;
import java.util.List;

public class CustomObjectSortingListOfObject_LambdaExpression {

	public static void main(String[] args) {
		List<Employee> list = EmployeeDB.getEmployees();
		Collections.sort(list, (T1, T2)-> T1.getName().compareTo(T2.getName()));
		list.forEach(System.out::println);

	}

}
