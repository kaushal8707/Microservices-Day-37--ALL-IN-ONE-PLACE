package com.selfdeveloped.java.interview;

@FunctionalInterface
public interface MyFunction { 
	String test(String s1, String s2);
}
