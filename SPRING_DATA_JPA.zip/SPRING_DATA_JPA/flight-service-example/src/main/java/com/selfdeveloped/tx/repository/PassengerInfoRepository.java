package com.selfdeveloped.tx.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.selfdeveloped.tx.entity.PassengerInfo;

public interface PassengerInfoRepository extends JpaRepository<PassengerInfo, Long>{

}
