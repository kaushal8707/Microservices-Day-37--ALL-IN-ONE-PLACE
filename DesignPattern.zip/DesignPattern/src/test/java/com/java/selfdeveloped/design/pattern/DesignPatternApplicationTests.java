package com.java.selfdeveloped.design.pattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesignPatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
