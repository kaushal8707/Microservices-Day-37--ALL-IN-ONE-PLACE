package com.java.selfdeveloped.patch.mapping.service;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import com.java.selfdeveloped.patch.mapping.entity.Product;
import com.java.selfdeveloped.patch.mapping.repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repository;


    public Product saveProduct(Product product) {
        return repository.save(product);
    }

    public List<Product> getProducts() {
        return repository.findAll();
    }

    public Product getProductById(int id) {
        return repository.findById(id).get();
    }


    public Product updateProduct(int id, Product productRequest) {
        // get the product from DB by id
        // update with new value getting from request
        Product existingProduct = repository.findById(id).get(); // DB
        existingProduct.setName(productRequest.getName());
        existingProduct.setDescription(productRequest.getDescription());
        existingProduct.setPrice(productRequest.getPrice());
        existingProduct.setProductType(productRequest.getProductType());
        return repository.save(existingProduct);
    }


    public long deleteProduct(int id) {
        repository.deleteById(id);
        return repository.count();
    }

	public Product updateProductByFields(int id, Map<String, Object> fields) {
		Product existingProduct = repository.findById(id).get();
		
		fields.forEach((key, value)->{
			
			Field field = ReflectionUtils.findField(Product.class, key);
			field.setAccessible(true);
			ReflectionUtils.setField(field, existingProduct, value);
		});
		return repository.save(existingProduct); 
	}
}
