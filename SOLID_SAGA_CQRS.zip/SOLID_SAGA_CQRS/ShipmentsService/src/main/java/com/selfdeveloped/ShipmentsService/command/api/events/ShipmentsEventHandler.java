package com.selfdeveloped.ShipmentsService.command.api.events;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import com.selfdeveloped.CommonService.events.OrderShippedEvent;
import com.selfdeveloped.ShipmentsService.command.api.data.Shipment;
import com.selfdeveloped.ShipmentsService.command.api.data.ShipmentRepository;

@Component
public class ShipmentsEventHandler {

	private ShipmentRepository shipmentRepository;
	
	public ShipmentsEventHandler(ShipmentRepository shipmentRepository) {
		this.shipmentRepository = shipmentRepository;
	}


	@EventHandler
	public void on(OrderShippedEvent event) {
		Shipment shipment 
				= new Shipment();
		
		shipment.setOrderId(event.getOrderId());
		shipment.setShipmentId(event.getShipmentId());
		shipment.setShipmentStatus(event.getShipmentStatus());
	    shipmentRepository.save(shipment);
	}
}


