package com.selfdeveloped.java.stream.api.related_program;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.util.comparator.Comparators;

public class Program3_Find_AVG_ScoreOfAllStudents 
{
	public static void main(String[] args) {
		List<StudentSapient> list= Arrays.asList(new StudentSapient(5,"zrtt",16),
                new StudentSapient(1,"raj",56),
                new StudentSapient(2,"hansh",12),
                new StudentSapient(3,"komal",34),
                new StudentSapient(4,"raghu",45)
                );
	
	// V. Imp
	// Find the name and score of student who got less than 35 score
	Map<String,Integer> map=list.stream().collect(Collectors.toMap(StudentSapient::getName,StudentSapient::getScore));
	map.entrySet().stream().filter(s->s.getValue()<35).collect(Collectors.toList()).forEach(System.out::println);
	
	// Find the name of student who got less than 35 score
	Map<String,Integer> map1=list.stream().collect(Collectors.toMap(StudentSapient::getName,StudentSapient::getScore));
	map1.entrySet().stream().filter(s->s.getValue()<35).map(e->e.getKey()).collect(Collectors.toList()).forEach(System.out::println);	
			
	// Find Average score of all the Sapient Student
	double avgScoreOfStudent=list.stream().map(StudentSapient::getScore)
											.mapToInt(a->a).average().getAsDouble();
	System.out.println("Avg Score "+avgScoreOfStudent);
	
	// Find Minimum score of the Sapient Student
	double minimumScore=list.stream().map(StudentSapient::getScore)
										.mapToInt(a->a).min().getAsInt();
	System.out.println("Minimum Score "+minimumScore);
	
	// How many student got score less than 35
	long c=list.stream().map(StudentSapient::getScore).filter(t->t<35).count();
	System.out.println(c);
	
	// Find sum/total score of the Sapient Student
	int sumOfScore=list.stream().map(StudentSapient::getScore)
										.mapToInt(a->a).sum();
	System.out.println("Total Score "+sumOfScore);
	
	}
}
