package com.selfdeveloped.java.stream.api.sort.list;
import java.util.Comparator;
import java.util.List;

public class CustomObjectSortingUsingStreamAPI
{
	public static void main(String[] args) {
		List<Employee> employees = EmployeeDB.getEmployees();
		
		//using stream API
		employees.stream().sorted(Comparator.comparing(emp->emp.getSalary())).forEach(System.out::println);
		
		//using comparator
		employees.stream().sorted((o1, o2)->o2.getName().compareTo(o1.getName()))
									.forEach(System.out::println);
		
		//using method reference
		employees.stream().sorted(Comparator.comparing(Employee::getId))
								.forEach(System.out::println);
		
		//find Highest Salary
		long highestSalary = employees.stream()
								.sorted(Comparator.comparing(Employee::getSalary)
											.reversed()).findFirst()
													.get().getSalary();
		System.out.println("Highest Salary = "+highestSalary);
		
		//find Lowest Salary Employee Name
		String name = employees.stream()
							.sorted(Comparator.comparing(Employee::getSalary))
											.findFirst().get().getName();
		System.out.println("Lowest Salary Employee Name= "+name);
		
		//find Lowest Salary Employee 
		Employee emp = employees.stream()
							.sorted(Comparator.comparing(Employee::getSalary))
											.findFirst().get();
		System.out.println("Lowest Salary Employee = "+emp);

	}
}
