package com.selfdeveloped.java.stream.api.related_program;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Program1_Find_Sum_Avg_Max_Min_Count {

	public static void main(String[] args) {
		
		// Find Sum/Avg/Max/Min of all Even Number.......!!!
		List<Integer> list = new ArrayList();
		for(int i=1;i<=99;i++) {
			list.add(i);
		}
		
		//using Collectors method
		Predicate<Integer> evenNumber = (t)->t%2==0;
		long sum=list.stream().filter(evenNumber).collect(Collectors.summarizingInt(i->i)).getSum();
		int average=list.stream().filter(evenNumber).collect(Collectors.averagingInt(a->a)).intValue();
		int count=list.stream().filter(evenNumber).collect(Collectors.counting()).intValue();
		int max=list.stream().filter(evenNumber).collect(Collectors.maxBy(Comparator.comparing(a->a))).get();
		int min=list.stream().filter(evenNumber).collect(Collectors.minBy(Comparator.comparing(a->a))).get();

		
		System.out.println("Min "+min);
		System.out.println("Max "+max);
		System.out.println("Counting "+count);
		System.out.println("Average "+average);
		System.out.println("Sum "+sum);
		

		
	}

}
