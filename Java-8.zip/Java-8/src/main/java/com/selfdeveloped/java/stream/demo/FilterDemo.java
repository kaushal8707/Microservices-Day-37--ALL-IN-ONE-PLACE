package com.selfdeveloped.java.stream.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

public class FilterDemo {
	
	//So, Filter internally using the Predicate Functional Interface, Predicate Internally having one abstract method 
	//i.e test () method, so we are writing lambda expression for that test method
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("perk");
		list.add("absco");
		list.add("defto");
		list.add("vesko");
		Predicate<String> cond = t->t.startsWith("p");
		list.stream().filter(cond).forEach(System.out::println);
		list.stream().filter(t->t.endsWith("o")).forEach(System.out::println);
		
		
		//Get the Even key from the maps….
		Map<Integer,String> map = new HashMap<Integer,String>();
		map.put(1, "one");
		map.put(2, "two");
		map.put(3, "three");
		map.put(4, "four");
		map.put(5, "five");
		map.entrySet().stream()
				.filter(entry->entry.getKey()%2==0)
					.forEach(System.out::println);
		
	}

}
