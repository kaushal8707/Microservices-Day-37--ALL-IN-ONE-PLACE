package com.selfdeveloped.java.stream.api.sort.map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class SortMapDemo_Traditional {

	//Sort Map Based on Key
	
	public static void main(String[] args) {

		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("two", 2);
		map.put("four", 4);
		map.put("six", 6);
		map.put("eight", 8);
		map.put("nine", 9);
		
		Set<Entry<String, Integer>> set = map.entrySet();
		List<Entry<String, Integer>> entries = new ArrayList(set);
		Collections.sort(entries, new Comparator<Entry<String, Integer>>() {
			
			public int compare(Entry<String, Integer> entry1, Entry<String, Integer> entry2){
				return entry1.getKey().compareTo(entry2.getKey());
			}
		});
		entries.forEach(System.out::println); 
	}

}
