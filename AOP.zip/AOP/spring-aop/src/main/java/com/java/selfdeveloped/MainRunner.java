package com.java.selfdeveloped;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.java.selfdeveloped.service.HiByeService;

@Component
public class MainRunner implements CommandLineRunner {

	@Autowired
	private HiByeService service;
	
	@Override
	public void run(String... args) throws Exception {
		
		service.sayHi("in28Minutes");
		service.sayBye();
		System.out.println(service.returnSomething());
		service.sayDemo("asd","qwe");
	}

}
