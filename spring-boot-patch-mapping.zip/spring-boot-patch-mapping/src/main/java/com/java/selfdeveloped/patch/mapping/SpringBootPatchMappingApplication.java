package com.java.selfdeveloped.patch.mapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPatchMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPatchMappingApplication.class, args);
	}

}
