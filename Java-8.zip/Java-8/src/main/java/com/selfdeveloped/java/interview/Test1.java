package com.selfdeveloped.java.interview;
import java.util.function.Function;

public class Test1 {
	public static void main(String[] args) {
		Function<Integer, String> function = (t)->"output: "+t;
		System.out.println(function.apply(12));
	} 
 }
