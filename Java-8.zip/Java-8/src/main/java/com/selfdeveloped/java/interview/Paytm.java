package com.selfdeveloped.java.interview;

public class Paytm implements UPIPayment  {

	@Override
	public String doPayment(String source, String dest) {
		String txDate=UPIPayment.datePatterns("yyyy-MM-dd");
		return null;
	}
	
	public double getScratchCard() {
		return UPIPayment.super.getScratchCard();
	}
}
