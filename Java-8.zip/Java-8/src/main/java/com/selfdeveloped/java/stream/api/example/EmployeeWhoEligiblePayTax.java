package com.selfdeveloped.java.stream.api.example;

import java.util.stream.Collectors;

public class EmployeeWhoEligiblePayTax {

	//Realtime Example for Stream & filter-----
	
	public static void main(String[] args) 
	{
		//An Employee who is having Salary more than 5 Lakhs is Eligible to Pay the Tax

		EmployeeDB.getEmployees().stream()
				.filter(t->t.getSalary()>500000)
					.collect(Collectors.toList()).forEach(System.out::println);
		
		System.out.println("=============================");

		//find the all department name whose Employees salaries is more than 5 lakhs
		
		EmployeeDB.getEmployees()
			.stream().filter(emp->emp.getSalary()>500000)
					.map(Employee->Employee.getDept())
							.collect(Collectors.toList()).forEach(System.out::println);
		
	}
	
	
	

}
