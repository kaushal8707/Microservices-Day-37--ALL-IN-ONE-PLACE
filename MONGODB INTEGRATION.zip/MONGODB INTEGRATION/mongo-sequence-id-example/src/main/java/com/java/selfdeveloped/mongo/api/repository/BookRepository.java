package com.java.selfdeveloped.mongo.api.repository;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.java.selfdeveloped.mongo.api.entity.Book;

public interface BookRepository extends MongoRepository<Book,Integer> {
}