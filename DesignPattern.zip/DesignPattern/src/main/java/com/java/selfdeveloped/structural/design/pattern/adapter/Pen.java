package com.java.selfdeveloped.structural.design.pattern.adapter;
//To write an Assignment we need a Pen right…, so create an Interface which is Pen Interface here.

public interface Pen {
	void write(String str);
}
