package com.java.selfdeveloped.structural.design.pattern.adapter;

public class PilotPen {

	public void mark(String str) {
		System.out.println(str); 
	}
}
