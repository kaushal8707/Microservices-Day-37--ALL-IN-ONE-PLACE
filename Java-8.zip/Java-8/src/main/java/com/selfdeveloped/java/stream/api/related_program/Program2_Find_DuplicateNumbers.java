package com.selfdeveloped.java.stream.api.related_program;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Program2_Find_DuplicateNumbers 
{
	public static void main(String[] args) {
		
        List<Integer> list= Arrays.asList(1,2,3,4,5,4,3,4,3,5,6);
        Set<Integer> findDuplicates =  list.stream().filter(t->Collections.frequency(list, t) > 1)
        										.collect(Collectors.toSet());
        findDuplicates.forEach(System.out::println);
        
        System.out.println("<<--------------------->>");
        
        //Another Way
        Set<Integer> set=new HashSet();
        list.stream().filter(t->!set.add(t))
        		.collect(Collectors.toSet()).forEach(System.out::println);
	}

}
