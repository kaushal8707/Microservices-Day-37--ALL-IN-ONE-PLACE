package com.selfdeveloped;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaManytomanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
