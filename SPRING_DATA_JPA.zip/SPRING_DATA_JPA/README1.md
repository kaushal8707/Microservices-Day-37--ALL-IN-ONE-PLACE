# Microservices-Day-16-Spring-Boot-Spring-Data-JPA-Transaction-Management-Transactional

Url-   POST   http://localhost:9191/bookFlightTicket

Payload--

{
 "passengerInfo": {
   "name": "kaushal",
   "email": "kaushal@gmail.com",
   "source": "Bangalore",
   "destination": "BBSR",
   "travelDate": "14-12-2022",
   "pickupTime": "4.0 PM",
   "arrivalTime": "6.0 PM",
   "fare": 11000.0
  },
  "paymentInfo": {
    "accountNo": "acc2",
    "cardType": "DEBIT"
  }
}
