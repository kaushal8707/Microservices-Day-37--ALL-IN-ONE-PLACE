package com.design.principle.ocp;


public class MobileNotificationService implements NotificationService{

	@Override
	public void sendOTP(String medium) {
		//write logic to integrate with Email API
		//using twillio api...bcz there are manyapi.
	}

	@Override
	public void sendTransactionReport(String medium) {
		//write logic to integrate with Email API
		//using twillio api...bcz there are manyapi.		
	}

}
