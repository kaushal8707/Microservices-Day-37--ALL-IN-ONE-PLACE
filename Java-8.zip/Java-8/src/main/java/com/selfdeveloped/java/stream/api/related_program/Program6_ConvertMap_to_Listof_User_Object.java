package com.selfdeveloped.java.stream.api.related_program;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Program6_ConvertMap_to_Listof_User_Object {

	public static void main(String[] args) {
		 //Convert Map to List of User Object Example and sort based on key 
        Map<Integer, String> map1 = new HashMap<>();
        map1.put(23, "Mahesh");
        map1.put(10, "Suresh");
        map1.put(26, "Dinesh");
        map1.put(11, "Kamlesh");

        List<Person> list = map1.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .map(e -> new Person(e.getKey(), e.getValue())).collect(Collectors.toList());

        list.forEach(System.out::println);
	}

}
