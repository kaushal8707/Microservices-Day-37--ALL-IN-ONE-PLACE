package com.selfdeveloped.java.stream.api.sort.map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class SortMapDemo_LambdaExpression {

	//Sort Map Based on Value
	
	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("two", 2);
		map.put("four", 4);
		map.put("six", 6);
		map.put("eight", 8);
		map.put("nine", 9);
		
		List<Entry<String, Integer>> list = new ArrayList(map.entrySet());
		Collections.sort(list, (entry1, entry2)-> entry1.getValue().compareTo(entry2.getValue()));
		list.forEach(entry -> System.out.println(entry.getKey()+"      "+entry.getValue()));
		
	}
}
