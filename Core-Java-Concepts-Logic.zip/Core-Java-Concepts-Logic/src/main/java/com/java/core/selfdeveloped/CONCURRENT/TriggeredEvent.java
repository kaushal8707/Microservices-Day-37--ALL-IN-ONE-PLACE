package com.java.core.selfdeveloped.CONCURRENT;

public class TriggeredEvent implements Runnable {

	public TriggeredEvent(int i) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
