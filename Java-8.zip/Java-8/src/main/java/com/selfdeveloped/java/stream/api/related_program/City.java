package com.selfdeveloped.java.stream.api.related_program;

public interface City
{
    void setName(String name);
    void setArea(int area);
    default String getBusinessType(){
        return "Service";
    }
}
