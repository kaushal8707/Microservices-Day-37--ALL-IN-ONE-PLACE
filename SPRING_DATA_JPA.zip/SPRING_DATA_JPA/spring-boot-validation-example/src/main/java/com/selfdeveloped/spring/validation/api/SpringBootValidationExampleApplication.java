package com.selfdeveloped.spring.validation.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootValidationExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootValidationExampleApplication.class, args);
	}

}
