package com.selfdeveloped.java.interview;

@FunctionalInterface
public interface TestInterface extends UPIPayment{

	//void test();
}
