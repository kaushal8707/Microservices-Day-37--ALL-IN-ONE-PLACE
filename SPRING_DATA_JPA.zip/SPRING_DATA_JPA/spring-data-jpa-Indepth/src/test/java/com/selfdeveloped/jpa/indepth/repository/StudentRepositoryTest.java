package com.selfdeveloped.jpa.indepth.repository;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.selfdeveloped.jpa.indepth.entity.Guardian;
import com.selfdeveloped.jpa.indepth.entity.Student;

@SpringBootTest
class StudentRepositoryTest {

	@Autowired
	private StudentRepository studentRepository;
	
	
	@Test
	public void saveStudent() {
		Student student = Student.builder()
				.firstName("Kaushal")
				.lastName("Singh")
				.emailId("kaushal.singh029@gmail.com")
				//.guardianName("Radhe Shyam Singh")
				//.guardianEmail("radheshyam.singh@gmail.com")
				//.guardianMobile("9999999999")
				.build();
		studentRepository.save(student);
	}
	
	@Test
	public void saveStudentWithGuardian() {
		Guardian guardian=Guardian.builder()
				.name("Radheshyam Singh")
				.email("radhe@gmail.com")
				.mobile("7079022052")
				.build();
		
		Student student=Student.builder()
				.firstName("bharat")
				.lastName("bhushan")
				.emailId("bharat@gmail.com")
				.guardian(guardian)
				.build();
		studentRepository.save(student);
	}

	@Test
	public void printAllStudent() {
		List<Student> studentList = 
				studentRepository.findAll();
		
		System.out.println(" studentList = "+studentList); 
	}

	@Test
	public void printStudentByFirstName() {
		List<Student> listOfStudents=
				studentRepository.findByFirstName("bharat");
		System.out.println("printStudentByFirstName " +listOfStudents);
	}
	
	@Test
	public void printStudentByFirstNameContaining() {
		List<Student> students=
				studentRepository.findByFirstNameContaining("ha");
		System.out.println("students " +students);
	}
	
	@Test
	public void printStudentBasedOnGuardianName() {
		List<Student> students=
				studentRepository.findByGuardianName("Radheshyam Singh");
		System.out.println("students " +students);
	}

	@Test
	public void printgetStudentByEmailAddress() {
		Student student =
				studentRepository.getStudentByEmailAddress("bharat@gmail.com"); 
		System.out.println(" student "+student);
	}
	
	@Test
	public void printgetStudentFirstNameByEmailAddress() {
		String firstName =
				studentRepository.getStudentFirstNameByEmailAddress("kaushal.singh029@gmail.com"); 
		System.out.println(" Student First name "+firstName);
	}
	
	@Test
	public void printStudentByEmailAddressNative() {
		Student student =
				studentRepository.getStudentByEmailAddressNative("bharat@gmail.com"); 
		System.out.println(" Student  "+student);
	}

	@Test
	public void printStudentByEmailAddressNativeNamedParam() {
		Student student =
				studentRepository.getStudentByEmailAddressNative("bharat@gmail.com"); 
		System.out.println(" Student  "+student);
	}

	@Test
	public void updateStudentNameByEmailId() {
		studentRepository.updateStudentNameByEmailId("kaushal kumar singh", "kaushal.singh029@gmail.com");
	}
	
	@Test
	public void deleteStudentNameByEmailId() {
		studentRepository.deleteStudentNameByEmailId("kaushal.singh029@gmail.com");
	}
}
