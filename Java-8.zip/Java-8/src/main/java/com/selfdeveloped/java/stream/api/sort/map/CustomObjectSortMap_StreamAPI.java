package com.selfdeveloped.java.stream.api.sort.map;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class CustomObjectSortMap_StreamAPI {

	public static void main(String[] args) {
		Map<Employee, Integer> map = new HashMap<Employee, Integer>();
		map.put(new Employee(28,"prakash","Mechanical",334651) , 2);
		map.put(new Employee(65,"sohan","Electronic",912736), 4);
		map.put(new Employee(39,"vinay","Hardware",451271), 6);
		map.put(new Employee(81,"dipesh","HR",874651), 8);
		
		//sort based on name of Employee
		map.entrySet().stream()
				.sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getName)))
												.forEach(System.out::println);
		//sort based on name of Employee In Reversed Order
		map.entrySet().stream()
					.sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getName).reversed()))
												.forEach(System.out::println);
		//sort map based on value
		map.entrySet().stream()
					.sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
		
		//find the name of employee whose salary is highest
		String employeeName= map.entrySet().stream()
								.sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getSalary)
											.reversed())).map(a->a.getKey().getName())
														.findFirst().get();
		System.out.println(employeeName);
		
		//find Name of the Person who is in HR Department
		String person = map.entrySet().stream()
								.filter(T->T.getKey().getDept().equals("HR"))
											.map(T->T.getKey().getName()).findAny().get();
		System.out.println("Person In HR Department = "+person);
		
	}

}
