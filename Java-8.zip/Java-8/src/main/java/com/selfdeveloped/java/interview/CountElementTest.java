package com.selfdeveloped.java.interview;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CountElementTest {
	public static void main(String[] args) {
		
			// creating stream of integers
			Stream<Integer> i = Stream.of(1, 2, 3, 4, 5, 6);
			// counting number of integer in stream
			long count_int = i.collect(Collectors.counting());
			System.out.println(count_int);
		
			// creating stream of strings
			Stream<String> s = Stream.of("Akash","Harsh","Shubham","Nishant","Pratik");
			// counting number of strings in stream
			long count_string = s.collect(Collectors.counting());
			System.out.println(count_string);
		}
	}

