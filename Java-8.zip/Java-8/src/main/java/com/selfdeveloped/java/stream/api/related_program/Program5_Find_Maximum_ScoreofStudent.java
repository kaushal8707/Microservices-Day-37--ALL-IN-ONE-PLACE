package com.selfdeveloped.java.stream.api.related_program;
import java.util.Arrays;
import java.util.List;

public class Program5_Find_Maximum_ScoreofStudent {

	public static void main(String[] args) {
		 List<StudentSapient> list= Arrays.asList(new StudentSapient(5,"zrtt",12),
	                new StudentSapient(1,"raj",56),
	                new StudentSapient(2,"hansh",23),
	                new StudentSapient(3,"komal",34),
	                new StudentSapient(4,"raghu",45)
	        );
		 int max_score_student = list.stream().map(StudentSapient::getScore).mapToInt(a->a).max().getAsInt();
		 System.out.println("Maximum Score of a Student "+max_score_student); 
	}

}
