package com.selfdeveloped.java.lambda.exp;
@FunctionalInterface
public interface Calculator {

	//void switchOn();
	void printNum(int num);

}
