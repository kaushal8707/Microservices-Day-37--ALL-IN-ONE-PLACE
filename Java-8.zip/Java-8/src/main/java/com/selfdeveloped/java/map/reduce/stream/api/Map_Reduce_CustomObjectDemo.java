package com.selfdeveloped.java.map.reduce.stream.api;

import java.util.Comparator;
import java.util.stream.Collectors;

public class Map_Reduce_CustomObjectDemo {
	public static void main(String[] args) {
		
		//find the Average Salary of those Employee Whose Grade is A
		//get Employee whose grade A
		//get Salary
		double avg_salary=EmployeeDatabase.getEmployees().stream()
					.filter(t->t.getGrade().equals("A"))
						.map(Employee::getSalary).mapToDouble(a->a).average().getAsDouble();
		System.out.println("Avg Salary  = "+avg_salary );
		
		
		//find the Sum Salary of those Employee Whose Grade is A
		//get Employee whose grade A
		//get Salary
		double sum_salary = EmployeeDatabase.getEmployees().stream()
					.filter(emp->emp.getGrade().equals("A"))
						.map(Employee::getSalary).mapToDouble(emp->emp).sum();
		System.out.println("Total salary = "+sum_salary);	
		
		
		//find the Name of Employees
		EmployeeDatabase.getEmployees().stream().map(Employee::getName).collect(Collectors.toList()).forEach(System.out::println);
		
		//find the highest salary
		double highest_salary = EmployeeDatabase.getEmployees().stream().map(Employee::getSalary)
									.mapToDouble(a->a).max().getAsDouble();
		System.out.println("highest_salary  "+highest_salary);
		
		//find the name of Highest_salary paid employee
		String emp_name_highest_salary_paid =EmployeeDatabase.getEmployees().stream()
											.sorted(Comparator.comparing(Employee::getSalary).reversed())
													.map(Employee::getName).findFirst().get();
		System.out.println("highest_salary employee name  "+emp_name_highest_salary_paid);
		
		//find Average Salary of those Employee whose grade is “A “.
		double average_salary = EmployeeDatabase.getEmployees().stream()
									.filter(emp->emp.getGrade().equals("A"))
										.map(Employee::getSalary).mapToDouble(a->a).average()
												.getAsDouble();
		
		System.out.println("average_salary  "+average_salary);

		//find the name of Employees whose salary is greater than 50000
		EmployeeDatabase.getEmployees().stream()
					.filter(emp->emp.getSalary()>50000).map(Employee::getName)
								.collect(Collectors.toList()).forEach(System.out::println);
	}
}
