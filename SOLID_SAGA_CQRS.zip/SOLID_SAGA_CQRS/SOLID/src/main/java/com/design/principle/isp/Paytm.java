package com.design.principle.isp;

public class Paytm implements UPIPayments {

    public void payMoney() {

    }
    public void getScratchCard() {

    }
	public void getCashBackAsCreditBalance() {
		// not applicable for paytm
		
	}
}
