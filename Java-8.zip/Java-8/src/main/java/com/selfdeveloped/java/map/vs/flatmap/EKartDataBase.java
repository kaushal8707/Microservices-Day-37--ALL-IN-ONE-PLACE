package com.selfdeveloped.java.map.vs.flatmap;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EKartDataBase {

	public static List<Customer> getAll()
	{
		return Stream.of(
				new Customer(101, 65478, "john", "john@gmail.com", Arrays.asList("8797651423","9191928273")),
				new Customer(102, 91324, "smith", "smith@gmail.com", Arrays.asList("7676767671","6545654321")),
				new Customer(103, 335678, "piter", "piter@gmail.com", Arrays.asList("2435243142","1213121312")),
				new Customer(104, 991132, "kely", "kely@gmail.com", Arrays.asList("7766554434","8877665544"))
		  ).collect(Collectors.toList());
	}
} 
