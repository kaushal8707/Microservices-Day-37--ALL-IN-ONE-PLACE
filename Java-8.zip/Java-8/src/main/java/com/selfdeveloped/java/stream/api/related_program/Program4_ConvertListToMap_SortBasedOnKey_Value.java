package com.selfdeveloped.java.stream.api.related_program;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Program4_ConvertListToMap_SortBasedOnKey_Value {

	public static void main(String[] args) {
		List<StudentSapient> list= Arrays.asList(new StudentSapient(5,"zrtt",16),
                new StudentSapient(1,"raj",56),
                new StudentSapient(2,"hansh",12),
                new StudentSapient(3,"komal",34),
                new StudentSapient(4,"raghu",45)
                );
		
		System.out.println("Sorting Based on Key");
		list.stream()
			.collect(Collectors.toMap(StudentSapient::getName, StudentSapient::getScore))
					.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(Collectors.toList())
							.forEach(System.out::println);
		
		System.out.println("Sorting Based on Value");
		list.stream()
		.collect(Collectors.toMap(StudentSapient::getName, StudentSapient::getScore))
				.entrySet().stream().sorted(Map.Entry.comparingByValue()).collect(Collectors.toList())
						.forEach(System.out::println);
	}
}
