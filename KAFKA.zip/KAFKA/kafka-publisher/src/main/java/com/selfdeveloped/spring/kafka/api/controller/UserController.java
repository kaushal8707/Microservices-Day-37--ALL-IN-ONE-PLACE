package com.selfdeveloped.spring.kafka.api.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.selfdeveloped.spring.kafka.api.model.User;


@RestController
public class UserController {

	@Autowired
	KafkaTemplate<String, Object> kafkaTemplate;
	
	@Value("${kafka.topic.name}")
	private String publishTopic;
	
	@GetMapping("/publish/{name}")
	public String publishMessage(@PathVariable String name)
	{
		kafkaTemplate.send(publishTopic, "Hi"+name+" Welcome to Self Happy Learning !!");
		return "Data Published";
	}

	@GetMapping("/publishJson")
	public String publishMessage()
	{
		User user=new User(675,"pqowiw",new String[] {"maksl","agstsyd","991"});
		kafkaTemplate.send(publishTopic, user);
		return "Json data Published";
	}
}
