package com.java.selfdeveloped.creational.design.pattern.singleton;

public class Singleton_Lazy_Instantiation {

	public static void main(String[] args) {
		//Abc obj1=new Abc();    	//The constructor Abc() is not visible
		
		
		Abx obj1=Abx.getInstance();
		Abx obj2=Abx.getInstance();

		System.out.println(obj1);
		System.out.println(obj2);
	}

}

class Abx{
	static Abx obj;
	private Abx() {
	}
	
	public static Abx getInstance(){
		if(obj==null) {
			obj = new Abx();
		}
			return obj;
	}
}
