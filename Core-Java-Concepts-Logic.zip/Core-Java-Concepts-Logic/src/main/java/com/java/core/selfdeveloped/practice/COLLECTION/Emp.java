package com.example.collection_framework;


public class Emp 
{
  String id;
  String name;
public Emp(String id, String name) {
	super();
	this.id = id;
	this.name = name;
}
@Override
public String toString() {
	return "Emp [id=" + id + ", name=" + name + "]";
}
  
  
}
