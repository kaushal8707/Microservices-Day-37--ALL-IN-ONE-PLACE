package com.java.core.selfdeveloped;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreJavaConceptsLogicApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreJavaConceptsLogicApplication.class, args);
	}

}
