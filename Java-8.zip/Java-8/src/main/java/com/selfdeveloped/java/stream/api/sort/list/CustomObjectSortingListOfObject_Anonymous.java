package com.selfdeveloped.java.stream.api.sort.list;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CustomObjectSortingListOfObject_Anonymous {

	public static void main(String[] args) {
		List<Employee> list = EmployeeDB.getEmployees();
		Collections.sort(list, new Comparator<Employee>() {
			
			public int compare(Employee e1, Employee e2) {
				return e1.getDept().compareTo(e2.getDept());
			}
		});
		
		for(Employee emp : list) {
			System.out.println(emp); 
		}

	}
}
