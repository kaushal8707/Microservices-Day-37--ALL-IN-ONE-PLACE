package com.java.selfdeveloped.creational.design.pattern.prototype;

public interface Prototype
{
    Prototype getClone();
}
