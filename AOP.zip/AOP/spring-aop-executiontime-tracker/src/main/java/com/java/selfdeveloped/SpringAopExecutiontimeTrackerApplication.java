package com.java.selfdeveloped;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAopExecutiontimeTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAopExecutiontimeTrackerApplication.class, args);
	}

}
