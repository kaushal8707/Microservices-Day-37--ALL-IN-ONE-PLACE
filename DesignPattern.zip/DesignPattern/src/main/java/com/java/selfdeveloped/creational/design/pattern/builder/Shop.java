package com.java.selfdeveloped.creational.design.pattern.builder;
//So, in case of parameterized constructor we must have to pass all parameter value and also should know the sequence of parameters. So, to create an object we should remember the sequence of the parameter…and we don’t want to set all the parameter only we want to set os or battery parameter.
//So, there is a problems
//1.We don’t want to pass all the parameters 
//2.Even if we pass the parameters we should know the sequence of all those parameters.
//That’s why we use Builder Design Pattern here…..

//Without Builder Design Pattern

public class Shop {

	public static void main(String[] args) {
		
		//Without Builder Design Pattern
		Phone p = new Phone("Android",2,"Qualcomm",5.5, 3100);
		System.out.println(p);
		
		//With Builder Design Pattern
		
		PhoneBuilder builder = new PhoneBuilder();
		Phone ph = builder.getPhone();
		System.out.println(ph); 
		
		
		Phone phone = new PhoneBuilder().setOs("Android").setRam(2).getPhone();
		System.out.println(phone); 

	}

}
